package by.itstep.channelRita.dto.user;

import lombok.Data;

@Data
public class UserUpdateDto {

    private Integer id;
    private String email;
    private String imageUrl;
}
