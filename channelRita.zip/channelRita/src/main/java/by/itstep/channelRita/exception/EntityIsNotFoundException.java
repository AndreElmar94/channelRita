package by.itstep.channelRita.exception;

public class EntityIsNotFoundException extends RuntimeException{

    public EntityIsNotFoundException(String message) {
        super(message);
    }

}
