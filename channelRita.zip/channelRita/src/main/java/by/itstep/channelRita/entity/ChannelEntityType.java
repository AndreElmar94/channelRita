package by.itstep.channelRita.entity;

public enum ChannelEntityType {

    PROGRAMMING,
    EDUCATION,
    TOURISM

}
