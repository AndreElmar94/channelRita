package by.itstep.channelRita.exception;

public class UserCredentialsAreTakenException extends RuntimeException{

    public UserCredentialsAreTakenException(String message) {
        super(message);
    }
}
